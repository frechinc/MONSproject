# ResolverPYNQaudio
To listen any file in ".wav" with the PYNQ board
