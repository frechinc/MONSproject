# emotions-analyser
In the first version, we will be abble to : 
- write questions in a doc file 
- read these questions
- record the answer 
- analyze it
- produce some results with graphs

In the second version, we add the possibilitie of :
- recognize any language and use the application in the language that we choose

