# translator
when someone speak in a microphone, the application will translate the speech and we will hear an audio translated.
