# deleting_noise
Deleting the noise in any ".wav" file.
  //not effective on PYNQ board yet

